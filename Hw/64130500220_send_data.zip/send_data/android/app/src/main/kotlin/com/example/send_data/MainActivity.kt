package com.example.send_data

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
