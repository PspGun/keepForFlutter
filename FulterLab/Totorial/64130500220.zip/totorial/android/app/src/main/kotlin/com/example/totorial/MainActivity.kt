package com.example.totorial

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
